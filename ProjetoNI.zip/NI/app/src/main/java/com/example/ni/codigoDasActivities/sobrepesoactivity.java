package com.example.ni.codigoDasActivities;


import com.example.ni.AlteradorDeTitulo.helperDoAlteradorDeTitulo;
import com.example.ni.R;

public class sobrepesoactivity extends helperDoAlteradorDeTitulo {
    @Override
    protected int getLayoutId() {
        return R.layout.activity_sobrepeso;
    }
}