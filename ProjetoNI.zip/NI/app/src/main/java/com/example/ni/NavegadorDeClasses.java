package com.example.ni;

import android.app.Activity;
import android.content.Intent;
import android.widget.ImageButton;

public class NavegadorDeClasses {
    /* o unico motivo da existencia desse codigo, é porque ao inves de eu ter que copiar e oclar o mesmo codigo pra todas activity que tem esse botao
    eu apenas pesquiso no layout qual botao por id BtnSair, e como todos layouts estao em extend helperDoAlteradorDeTitulo, eu coloco Esse codigo lá e em seguida
    todos os layouts que tiverem um Button com nome BtnSair e que estejam ligados ao BaseIMCACtivity, vao ter a funcao de retornar a MainPage e encerrar
     a activity
     */

    public static void VoltarParaMain(Activity activity, int buttonId) {
        ImageButton btnSair = activity.findViewById(buttonId);
        if (btnSair != null) {
            btnSair.setOnClickListener(v -> {
                // Fecha a Activity atual e volta para a MainActivity
                Intent intent = new Intent(activity, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Limpa atodas activities
                activity.startActivity(intent);
                activity.finish(); // encerra a Activity atual
            });
        }
    }
}