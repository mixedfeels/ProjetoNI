package com.example.ni.AlteradorDeTitulo;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.ni.NavegadorDeClasses;
import com.example.ni.R;

public abstract class helperDoAlteradorDeTitulo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getLayoutId());

        // configura o btnSair ( esta em todos layouts de peso)
        NavegadorDeClasses.VoltarParaMain(this, R.id.BtnSair);

        // Recuperar dados do Intent
        double peso = getIntent().getDoubleExtra("PESO", 0);
        double altura = getIntent().getDoubleExtra("ALTURA", 0);
        String faixaIMC = getIntent().getStringExtra("FAIXA_IMC");

        // Atualizar o TextView Titulo
        TextView titulo = findViewById(R.id.Titulo);
        if (titulo == null) {
            Log.e("helperDoAlteradorDeTitulo", "TextView Titulo não encontrado no layout!");
            return;
        }
        AlteradorDeTitulo.atualizarTitulo(this, titulo, peso, altura, faixaIMC);
    }

    protected abstract int getLayoutId();
}