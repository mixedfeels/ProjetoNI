package com.example.ni.codigoDasActivities;

import android.os.Bundle;

import com.example.ni.AlteradorDeTitulo.helperDoAlteradorDeTitulo;
import com.example.ni.R;

public class obesidade3activity extends helperDoAlteradorDeTitulo {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_obesidade3;
    }
}