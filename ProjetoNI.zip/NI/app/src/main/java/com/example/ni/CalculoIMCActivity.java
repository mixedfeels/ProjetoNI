package com.example.ni;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.ni.codigoDasActivities.abaixopesoactivity;
import com.example.ni.codigoDasActivities.normalpesoactivity;
import com.example.ni.codigoDasActivities.obesidade1activity;
import com.example.ni.codigoDasActivities.obesidade2activity;
import com.example.ni.codigoDasActivities.obesidade3activity;
import com.example.ni.codigoDasActivities.sobrepesoactivity;

public class CalculoIMCActivity extends AppCompatActivity {
    private static final String TAG = "CalculoIMCActivity";

    private EditText editTextAltura, editTextPeso;
    private Button calcularIMCBtn;
    private ImageButton clearAlturaButton, clearPesoButton, sairButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculoimc);

        // Registrar todos botoes que vou usar nesse codigo
        editTextAltura = findViewById(R.id.edittext_altura);
        editTextPeso = findViewById(R.id.edittext_peso);
        calcularIMCBtn = findViewById(R.id.CalcularIMCBtn);
        clearAlturaButton = findViewById(R.id.clearAlturaButton);
        clearPesoButton = findViewById(R.id.clearPesoButton);
        sairButton = findViewById(R.id.SairButton);

        // Todos listeners para que ao ser clicado, execute algo seja limpar os dados ( requisito da avaliaçaoNI ) ou voltar para o menu principal ( sairButton)
        calcularIMCBtn.setOnClickListener(v -> calculodoimc());

        clearAlturaButton.setOnClickListener(v -> editTextAltura.setText(""));

        clearPesoButton.setOnClickListener(v -> editTextPeso.setText(""));

        sairButton.setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
    }


    private void calculodoimc() {
        // Pegando os valores de altura e peso
        String alturaText = editTextAltura.getText().toString();
        String pesoText = editTextPeso.getText().toString();

        // se uma das caixas de input estiverem vazias, o app da um aviso pro user preencher
        if (alturaText.isEmpty() || pesoText.isEmpty()) {
            Toast.makeText(CalculoIMCActivity.this, "Por favor, preencha tudo", Toast.LENGTH_SHORT).show();
            return;
        }

        // Convertendo para double para o cálculo
        double altura = Double.parseDouble(alturaText);
        double peso = Double.parseDouble(pesoText);

        // Calculo do imc ( espero estar certo pq tinha duvida se era (altura,altura) ou (altura,2)
        double imc = peso/Math.pow(altura, 2);  // IMC = peso / altura²

        // if infinito pra definir qual faixa do imc o user ta
        String faixaIMC;
        if (imc < 18.5) {
            faixaIMC = "abaixo_do_peso";
        } else if (imc >= 18.5 && imc < 24.9) {
            faixaIMC = "normal";
        } else if (imc >= 25 && imc < 29.9) {
            faixaIMC = "sobrepeso";
        } else if (imc >= 30 && imc < 34.9) {
            faixaIMC = "obesidade_grau_1";
        } else if (imc >= 35 && imc < 39.9) {
            faixaIMC = "obesidade_grau_2";
        } else {
            faixaIMC = "obesidade_grau_3";
        }
        // Intent para abrir a Activity correspondente
        Intent intent = new Intent(this, getTargetActivity(faixaIMC));
        intent.putExtra("PESO", peso);
        intent.putExtra("ALTURA", altura);
        intent.putExtra("FAIXA_IMC", faixaIMC);
        startActivity(intent);
        Log.i(TAG, faixaIMC);


    }
// esse bloco de codigo atribui a faixa imc a seu respectivo layout ( um para cada imc assim como as instrucoes pediram, apesar de ser mais facil ter criado um que se altera para todas)
    private Class<?> getTargetActivity(String faixaIMC) {
        switch (faixaIMC) {
            case "abaixo_do_peso": return abaixopesoactivity.class;
            case "normal": return normalpesoactivity.class;
            case "sobrepeso": return sobrepesoactivity.class;
            case "obesidade_grau_1": return obesidade1activity.class;
            case "obesidade_grau_2": return obesidade2activity.class;
            case "obesidade_grau_3": return obesidade3activity.class;
            default: throw new IllegalArgumentException("A classificacao nao existe!");
        }
    }
}


