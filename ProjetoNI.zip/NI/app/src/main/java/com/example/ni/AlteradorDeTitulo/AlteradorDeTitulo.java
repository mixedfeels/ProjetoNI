package com.example.ni.AlteradorDeTitulo;

import android.content.Context;
import android.widget.TextView;

public class AlteradorDeTitulo {
/*oque esse codigo faz, ele é responsavel por alterar o titulo e apenas. A partir da faixaIMC ele formata o texto a ser representado pelo TextView de idTitulo.*/
    public static void atualizarTitulo(Context context, TextView tituloTextView, double peso, double altura, String faixaIMC) {
        // Buscar a string formatada do resources
        String classificacao = getStringResource(context, faixaIMC);
        String texto = String.format(" com o peso de %.1f kg, altura de %.2f m voce se encontra em  %s", peso, altura, classificacao);
        tituloTextView.setText(texto);
    }

    private static String getStringResource(Context context, String resourceName) {
        int resId = context.getResources().getIdentifier(
                resourceName,
                "string",
                context.getPackageName()
        );
        return resId != 0 ? context.getString(resId) : resourceName;
    }
}